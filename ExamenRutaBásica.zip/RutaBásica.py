def navigation_step(option, continue_responses):
    destination = ""
    
    # Case 1
    if option == 1:
        destination = "ciudad de Huánuco"
    #Case 2
    elif option == 2:
        destination = "ciudad de Huancayo"
    #Default
    else:
        if option == 0:
            return "Salir"
        else:
            return "Opción no válida"

    steps_to_destination = 3  # Número de pasos para llegar al destino
    current_step = 0

    for continuar in continue_responses:
        if continuar == "sí":
            current_step += 1
            if current_step == steps_to_destination:
                return f"Has llegado a la {destination}."
        elif continuar == "no":
            return f"Deteniéndote en el camino a la {destination}."
        else:
            return "Respuesta no válida"

    return f"Avanzando hacia la {destination}... Paso {current_step} de {steps_to_destination}."


def navigation():
    while True:
        print("Menú de rutas:")
        print("1. Ruta a la ciudad de Huánuco")
        print("2. Ruta a la ciudad de Huáncayo")
        print("0. Salir")

        option = int(input("Seleccione una opción: "))
        
        continue_responses = []
        for _ in range(3):  # Limitar a 3 para evitar bucles infinitos
            response = input(f"¿Quieres continuar hacia el destino? (sí/no): ").strip().lower()
            continue_responses.append(response)

        result = navigation_step(option, continue_responses)
        print(result)

        if result == "Salir":
            break

        continuar_programa = input("¿Desea seleccionar otra ruta? (sí/no): ").strip().lower()
        if continuar_programa != "sí":
            print("Finalizando la Simulación ha llegado a su destino...")
            break

    return "Simulación Finalizada"

if __name__ == "__main__":
    resultado = navigation()
    print(resultado)


#############################

import unittest

class TestNavigation(unittest.TestCase):
    
    def test_ruta_a(self):
        result = navigation_step(1, ["sí", "sí", "sí"])
        self.assertEqual(result, "Has llegado a la ciudad de Huánuco.")
        
    def test_ruta_b(self):
        result = navigation_step(2, ["sí", "sí", "sí"])
        self.assertEqual(result, "Has llegado a la ciudad de Huancayo.")
        
    def test_detenerse_a(self):
        result = navigation_step(1, ["sí", "no"])
        self.assertEqual(result, "Deteniéndote en el camino a la ciudad de Huánuco.")
        
    def test_opcion_no_valida(self):
        result = navigation_step(3, ["sí"])
        self.assertEqual(result, "Opción no válida")
        
    def test_respuesta_no_valida(self):
        result = navigation_step(1, ["quizás"])
        self.assertEqual(result, "Respuesta no válida")
        
    def test_salir(self):
        result = navigation_step(0, [])
        self.assertEqual(result, "Salir")

if __name__ == "__main__":
    unittest.main()

    #CAMINOS RUTA 1:
    # I -> RUTA 1, P1 SÍ, P2 SÍ, P3 SÍ, P4 FIN    ---> P1 V, P2 V, P3, V = V
    # I -> RUTA 1, P1 SÍ, P2 NO, P3 FIN           ---> P1 V, P2 NO = F
    # I -> RUTA 1, P1 NO                          ---> P1 F = F

    #CAMINOS RUTA 2:
    # I -> RUTA 2, P1 SÍ, P2 SÍ, P3 SÍ, P4 FIN    ---> P1 V, P2 V, P3, V = V
    # I -> RUTA 2, P1 SÍ, P2 NO, P3 FIN           ---> P1 V, P2 NO = F
    # I -> RUTA 2, P1 NO, P2 FIN                  ---> P1 F = F